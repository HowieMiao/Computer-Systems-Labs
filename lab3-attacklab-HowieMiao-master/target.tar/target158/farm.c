/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_285(unsigned *p)
{
    *p = 1281999704U;
}

unsigned getval_153()
{
    return 163780818U;
}

void setval_437(unsigned *p)
{
    *p = 2428995912U;
}

unsigned addval_326(unsigned x)
{
    return x + 3347666955U;
}

unsigned addval_162(unsigned x)
{
    return x + 3273172680U;
}

unsigned getval_238()
{
    return 3251079496U;
}

unsigned getval_128()
{
    return 600019032U;
}

void setval_197(unsigned *p)
{
    *p = 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_377()
{
    return 3281044105U;
}

unsigned addval_331(unsigned x)
{
    return x + 3229139593U;
}

unsigned addval_472(unsigned x)
{
    return x + 3281044105U;
}

unsigned getval_484()
{
    return 3674787529U;
}

void setval_307(unsigned *p)
{
    *p = 3378565513U;
}

unsigned addval_275(unsigned x)
{
    return x + 3767093454U;
}

unsigned addval_110(unsigned x)
{
    return x + 2425474697U;
}

void setval_414(unsigned *p)
{
    *p = 2429618643U;
}

void setval_350(unsigned *p)
{
    *p = 1606602377U;
}

unsigned getval_411()
{
    return 214159745U;
}

void setval_427(unsigned *p)
{
    *p = 3676885385U;
}

void setval_186(unsigned *p)
{
    *p = 3232027017U;
}

unsigned addval_430(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_228()
{
    return 2430634328U;
}

unsigned getval_242()
{
    return 3353381192U;
}

unsigned getval_379()
{
    return 3268315646U;
}

void setval_317(unsigned *p)
{
    *p = 2430635336U;
}

unsigned addval_219(unsigned x)
{
    return x + 2425409163U;
}

unsigned addval_205(unsigned x)
{
    return x + 3380924041U;
}

void setval_104(unsigned *p)
{
    *p = 2447411528U;
}

unsigned getval_371()
{
    return 3286270280U;
}

void setval_122(unsigned *p)
{
    *p = 3281047937U;
}

void setval_240(unsigned *p)
{
    *p = 3531919753U;
}

unsigned getval_258()
{
    return 3374371209U;
}

void setval_217(unsigned *p)
{
    *p = 3526410889U;
}

unsigned getval_137()
{
    return 2425406093U;
}

unsigned addval_483(unsigned x)
{
    return x + 4039623305U;
}

void setval_413(unsigned *p)
{
    *p = 2425405961U;
}

unsigned addval_130(unsigned x)
{
    return x + 3229929101U;
}

void setval_354(unsigned *p)
{
    *p = 3677933193U;
}

unsigned getval_407()
{
    return 3353381192U;
}

unsigned addval_473(unsigned x)
{
    return x + 3223896713U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
